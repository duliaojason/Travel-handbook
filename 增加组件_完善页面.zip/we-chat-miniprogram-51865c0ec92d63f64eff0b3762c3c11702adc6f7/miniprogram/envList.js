// const envList = [{"envId":"cloud1-0g7vhwbu11c6494c","alias":"cloud1"}]
// const isMac = false
// module.exports = {
//     envList,
//     isMac
// }