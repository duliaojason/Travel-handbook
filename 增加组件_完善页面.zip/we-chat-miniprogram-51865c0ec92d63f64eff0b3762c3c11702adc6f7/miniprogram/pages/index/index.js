var app = getApp()

// 连接云数据集photos
const db = wx.cloud.database()
const photos = db.collection('photos')

Page({
  /**
   * 页面的初始数据
   */
  data: {
    isLoad: app.globalData.isLoad,
    slideShowList: [{
      url: '/image/banner/banner_4.jpg'
    }, {
      url: "/image/banner/banner_5.jpg"
    }, {
      url: "/image/banner/banner_6.jpg"
    }],
    makePic: '/image/banner/banner_make_2.jpg'

  },
  /**
   * 自定义函数--获取用户个人信息
   */
  getUserInfo: function (e) {
    var that = this
      app.getUserProfile().then(res=>{
          that.setData({
            isLoad:app.globalData.isLoad,
            userInfo:app.globalData.userInfo
          })
          console.log("data",that.data)
      });

    // 检测是否已经获取了用户的openid
    if (app.globalData.openid == null) {
      // 如果是第一次登陆则使用云函数获取用户openid
      wx.cloud.callFunction({
        name: 'getOpenid',
        complete: res => {
          // 尝试打印用户的openid，看是否获取成功
          // console.log("打印"+res.result.openid)

          // 将用户openid信息存在全局变量openid中
          app.globalData.openid = res.result.openid
        }
      })
    }
    this.setData({
      isLoad:true
    })

  },
  /**
   * 自定义函数--跳转上传图片页add
   */
  goToMake: function () {
    wx.navigateTo({
      url: '../make/make',
      // url: '../point_message/point_message',
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('globalData',app.globalData)
    this.setData({
      userInfo:app.globalData.userInfo,
      isLoad:app.globalData.isLoad
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (options) {
    this.setData({
      userInfo:app.globalData.userInfo,
      isLoad:app.globalData.isLoad
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})